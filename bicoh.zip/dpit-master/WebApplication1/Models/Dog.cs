﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class Dog
    {
        [Key]
        public int MagazineId { get; set; }

        [Required]
        [MaxLength(255)]
        [DisplayName("Dog Name")]
        public string DogName { get; set; }
        [Required]
        [DisplayName("Race")]
        public string Race { get; set; }

        [Required]
        [DisplayName("Age")]
        public string Age { get; set; }

        [Required]
        [DisplayName("Location")]
        public string location { get; set; }
    }
}
